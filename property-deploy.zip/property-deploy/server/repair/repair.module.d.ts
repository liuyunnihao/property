export declare class RepairModule {
}
