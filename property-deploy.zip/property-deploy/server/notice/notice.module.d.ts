export declare class NoticeModule {
}
